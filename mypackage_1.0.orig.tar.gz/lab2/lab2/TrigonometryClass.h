#pragma once


class TrigonometryClass {
public:
	// double x - argument of funciton
	// n - number of elements in sequence

	double FuncA(double x, int n);
};
