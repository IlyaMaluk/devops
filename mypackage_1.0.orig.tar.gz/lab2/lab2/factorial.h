#pragma once

unsigned long long factorial(int n);