#pragma once
#include<vector>

std::vector<int> euler_numbers = { 1, 0, -1, 0, 5, 0, -61, 0, 1385, 0, -50521, 0 };